/**
 * FlashDeal Content Script
 * Runs on web pages to detect shopping sites, find and apply coupon codes,
 * and convert normal links to affiliate links.
 */

// Constants
const EXTENSION_VERSION = '1.0.0';
const DEBUG_MODE = true;

// Setup
let isShoppingSite = false;
let isCheckoutPage = false;
let merchantName = '';
let dealsTested = 0;
let bestDiscount = 0;
let bestCode = '';

// Cache for affiliate links to avoid frequent API calls
const affiliateLinkCache = {};

// Initialize when the page loads
document.addEventListener('DOMContentLoaded', initialize);

/**
 * Initialize the extension content script
 */
function initialize() {
  log('Initializing FlashDeal content script...');
  
  // Extract merchant name from URL
  merchantName = extractMerchantFromUrl(window.location.href);
  log(`Detected merchant: ${merchantName}`);
  
  // Determine if this is a shopping site
  checkIfShoppingSite();
  
  // If this is a shopping site, start main processes
  if (isShoppingSite) {
    log(`Shopping site detected: ${merchantName}`);
    
    // Convert links to affiliate links
    processPageLinks();
    
    // Watch for DOM changes (dynamic content loading)
    observeDOMChanges();
    
    // Check if this is a checkout page
    checkIfCheckoutPage();
    
    // If this is a checkout page, look for coupon fields
    if (isCheckoutPage) {
      log('Checkout page detected, searching for coupon fields...');
      findCouponFields();
    }
  }
}

/**
 * Process page links to convert them to affiliate links
 */
function processPageLinks() {
  log('Processing page links for affiliate conversion...');
  
  // Get all links on the page
  const links = document.querySelectorAll('a[href]');
  
  // Process each link
  links.forEach(async (link) => {
    const originalUrl = link.href;
    
    // Skip non-http links, internal links, and already processed links
    if (!originalUrl.startsWith('http') || 
        originalUrl.includes(window.location.hostname) ||
        originalUrl.includes('skimresources.com') ||
        link.dataset.flashdealProcessed) {
      return;
    }
    
    // Mark as processed to avoid duplicate processing
    link.dataset.flashdealProcessed = 'true';
    
    try {
      // Check cache first
      if (affiliateLinkCache[originalUrl]) {
        link.href = affiliateLinkCache[originalUrl];
        log(`Using cached affiliate link for ${originalUrl}`);
        return;
      }
      
      // Send message to background script to convert link
      chrome.runtime.sendMessage({
        action: 'convertToAffiliateLink',
        originalUrl: originalUrl,
        merchantName: extractMerchantFromUrl(originalUrl)
      }, response => {
        if (response && response.success && response.affiliateUrl) {
          // Update the link
          link.href = response.affiliateUrl;
          
          // Cache the result
          affiliateLinkCache[originalUrl] = response.affiliateUrl;
          
          // Add click tracking
          link.addEventListener('click', function(e) {
            // Track the affiliate link click
            chrome.runtime.sendMessage({
              action: 'TRACK_EVENT',
              eventName: 'affiliate_link_click',
              eventParams: {
                merchant_name: response.merchantName,
                affiliate_network: response.affiliateNetwork,
                url: response.affiliateUrl
              }
            });
          });
          
          log(`Converted link to affiliate: ${originalUrl} -> ${response.affiliateUrl}`);
        }
      });
    } catch (error) {
      console.error('Error processing link:', error);
    }
  });
}

/**
 * Set up an observer to watch for DOM changes
 * This helps detect dynamically loaded content
 */
function observeDOMChanges() {
  // Create a MutationObserver to watch for DOM changes
  const observer = new MutationObserver((mutations) => {
    let shouldProcessLinks = false;
    
    // Check if relevant mutations occurred
    mutations.forEach(mutation => {
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE) {
            // If new elements were added, check for links
            const hasLinks = node.tagName === 'A' || node.querySelectorAll('a').length > 0;
            if (hasLinks) {
              shouldProcessLinks = true;
            }
            
            // If checkout page, check for new coupon fields
            if (isCheckoutPage) {
              const potentialCouponInputs = node.querySelectorAll('input[type="text"], input:not([type])');
              if (potentialCouponInputs.length > 0) {
                checkForCouponFields(potentialCouponInputs);
              }
            }
          }
        }
      }
    });
    
    // Process links if needed
    if (shouldProcessLinks) {
      processPageLinks();
    }
  });
  
  // Start observing the document
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}

/**
 * Check if the current site is a shopping site
 */
function checkIfShoppingSite() {
  // List of known shopping domains
  const knownShoppingDomains = [
    'amazon', 'walmart', 'ebay', 'target', 'bestbuy', 'etsy', 'homedepot', 'lowes',
    'macys', 'nordstrom', 'kohls', 'costco', 'staples', 'newegg', 'wayfair', 'overstock'
  ];
  
  // Check if current domain contains any known shopping domain
  isShoppingSite = knownShoppingDomains.some(domain => 
    window.location.hostname.includes(domain)
  );
  
  // Additional checks for shopping indicators
  if (!isShoppingSite) {
    // Check for common shopping page elements
    const hasCart = document.querySelectorAll('.cart, #cart, [class*="cart"], [id*="cart"]').length > 0;
    const hasPrice = document.querySelectorAll('.price, #price, [class*="price"], [id*="price"]').length > 0;
    const hasProduct = document.querySelectorAll('.product, #product, [class*="product"], [id*="product"]').length > 0;
    
    isShoppingSite = hasCart && hasPrice && hasProduct;
  }
  
  return isShoppingSite;
}

/**
 * Check if the current page is a checkout page
 */
function checkIfCheckoutPage() {
  // URL indicators
  const checkoutUrlIndicators = ['checkout', 'cart', 'basket', 'order', 'payment'];
  const isCheckoutUrl = checkoutUrlIndicators.some(indicator => 
    window.location.pathname.toLowerCase().includes(indicator)
  );
  
  // Page content indicators
  const checkoutIndicatorElements = document.querySelectorAll(
    '.checkout, #checkout, [class*="checkout"], [id*="checkout"], ' +
    '.cart, #cart, [class*="cart-page"], [id*="cart-page"], ' +
    '.payment, #payment, [class*="payment"], [id*="payment"]'
  );
  
  const hasCheckoutForms = document.querySelectorAll('form').length > 0;
  
  // Check for payment method indicators
  const paymentIndicators = ['credit card', 'debit card', 'payment method', 'billing', 'shipping', 'address'];
  const pageText = document.body.innerText.toLowerCase();
  const containsPaymentText = paymentIndicators.some(indicator => 
    pageText.includes(indicator)
  );
  
  // Determine if it's a checkout page
  isCheckoutPage = (isCheckoutUrl || checkoutIndicatorElements.length > 0) && 
                   (hasCheckoutForms && containsPaymentText);
  
  return isCheckoutPage;
}

/**
 * Find coupon or promo code fields on the checkout page
 */
function findCouponFields() {
  // Common selectors for coupon code inputs
  const couponInputSelectors = [
    'input[name*="coupon"], input[id*="coupon"], input[class*="coupon"]',
    'input[name*="promo"], input[id*="promo"], input[class*="promo"]',
    'input[name*="discount"], input[id*="discount"], input[class*="discount"]',
    'input[name*="gift"], input[id*="gift"], input[class*="gift"]',
    'input[placeholder*="coupon" i], input[placeholder*="promo" i], input[placeholder*="discount" i]'
  ];
  
  // Find potential coupon inputs
  const couponInputs = document.querySelectorAll(couponInputSelectors.join(', '));
  
  // Check each potential input
  checkForCouponFields(couponInputs);
}

/**
 * Check if inputs are likely coupon fields
 * @param {NodeList} inputs - List of input elements to check
 */
function checkForCouponFields(inputs) {
  if (inputs.length === 0) return;
  
  inputs.forEach(input => {
    // Skip hidden, disabled, or already processed inputs
    if (input.type === 'hidden' || 
        input.disabled || 
        input.dataset.flashdealProcessed) {
      return;
    }
    
    // Check for coupon indicators
    const isCouponInput = 
      input.name?.toLowerCase().match(/coupon|promo|discount|code|gift/i) ||
      input.id?.toLowerCase().match(/coupon|promo|discount|code|gift/i) ||
      input.placeholder?.toLowerCase().match(/coupon|promo|discount|code|gift/i) ||
      input.className?.toLowerCase().match(/coupon|promo|discount|code|gift/i);
    
    if (isCouponInput) {
      log('Found coupon input field:', input);
      
      // Mark as processed to avoid duplicate handling
      input.dataset.flashdealProcessed = 'true';
      
      // Find the associated apply button
      const applyButton = findAssociatedButton(input);
      
      if (applyButton) {
        // Show the FlashDeal UI
        showFlashDealUI(input, applyButton);
      }
    }
  });
}

/**
 * Find the button associated with a coupon input
 * @param {Element} input - The coupon input element
 * @returns {Element|null} - The apply button element or null if not found
 */
function findAssociatedButton(input) {
  // Look for buttons near the input
  const form = input.closest('form');
  if (form) {
    // Look for buttons within the same form
    const buttons = form.querySelectorAll('button, input[type="submit"], [role="button"]');
    
    for (const button of buttons) {
      const buttonText = button.innerText?.toLowerCase() || '';
      if (buttonText.match(/apply|submit|ok|go|update|check/i)) {
        return button;
      }
    }
    
    // If no semantically matching button, return the first button
    if (buttons.length > 0) {
      return buttons[0];
    }
  }
  
  // Look for nearby buttons if not in a form
  const parentElement = input.parentElement;
  if (parentElement) {
    const buttons = parentElement.querySelectorAll('button, input[type="submit"], [role="button"]');
    
    if (buttons.length > 0) {
      return buttons[0];
    }
    
    // Try one more level up
    const grandParent = parentElement.parentElement;
    if (grandParent) {
      const buttons = grandParent.querySelectorAll('button, input[type="submit"], [role="button"]');
      
      if (buttons.length > 0) {
        return buttons[0];
      }
    }
  }
  
  return null;
}

/**
 * Show the FlashDeal UI for automatic coupon application
 * @param {Element} couponInput - The coupon input field
 * @param {Element} applyButton - The apply button
 */
function showFlashDealUI(couponInput, applyButton) {
  // Create FlashDeal UI container
  const container = document.createElement('div');
  container.className = 'flashdeal-coupon-container';
  container.style.cssText = `
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    border: 2px solid #1E88E5;
    border-radius: 8px;
    padding: 10px 15px;
    margin: 10px 0;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    position: relative;
  `;
  
  // Add logo and title
  container.innerHTML = `
    <div style="display: flex; align-items: center; margin-bottom: 8px;">
      <img src="${chrome.runtime.getURL('icons/icon48.png')}" alt="FlashDeal" width="24" height="24" style="margin-right: 8px;" />
      <span style="font-weight: bold; color: #1E88E5;">FlashDeal</span>
    </div>
    <div class="flashdeal-message" style="margin-bottom: 10px;">
      Let FlashDeal automatically find the best coupon code for you!
    </div>
    <button class="flashdeal-auto-apply" style="
      background-color: #FF9800;
      color: white;
      border: none;
      border-radius: 4px;
      padding: 8px 12px;
      cursor: pointer;
      font-weight: bold;
    ">Auto-Apply Best Coupon</button>
    <div class="flashdeal-status" style="margin-top: 8px; font-size: 0.9em; display: none;"></div>
  `;
  
  // Insert the UI before the coupon input
  couponInput.parentElement.insertBefore(container, couponInput);
  
  // Get references to UI elements
  const autoApplyButton = container.querySelector('.flashdeal-auto-apply');
  const statusElement = container.querySelector('.flashdeal-status');
  
  // Add click handler for the auto-apply button
  autoApplyButton.addEventListener('click', () => {
    // Show status
    statusElement.style.display = 'block';
    statusElement.textContent = 'Searching for coupons...';
    
    // Start testing coupons
    testCoupons(couponInput, applyButton, statusElement);
  });
}

/**
 * Test coupon codes automatically
 * @param {Element} couponInput - The coupon input field
 * @param {Element} applyButton - The apply button
 * @param {Element} statusElement - The status display element
 */
function testCoupons(couponInput, applyButton, statusElement) {
  // For demo, we'll use some sample coupon codes
  // In a real implementation, these would come from a backend API
  const testCodes = [
    'WELCOME10',
    'SAVE20',
    'FREESHIP',
    'FLASH25',
    'DISCOUNT15',
    'DEAL30'
  ];
  
  // Reset tracking variables
  dealsTested = 0;
  bestDiscount = 0;
  bestCode = '';
  
  // Send message to get coupons for this site
  chrome.runtime.sendMessage({
    action: 'getCouponsForSite',
    merchantName: merchantName,
    url: window.location.href
  }, response => {
    let couponsToTest = testCodes;
    
    // If we get coupons from the backend, use those instead
    if (response && response.success && response.coupons && response.coupons.length > 0) {
      couponsToTest = response.coupons;
    }
    
    // Update status
    statusElement.textContent = `Testing ${couponsToTest.length} coupons...`;
    
    // Start testing coupons
    testNextCoupon(couponsToTest, 0, couponInput, applyButton, statusElement);
  });
}

/**
 * Test the next coupon in the list
 * @param {Array} coupons - List of coupon codes to test
 * @param {number} index - Current index in the list
 * @param {Element} couponInput - The coupon input field
 * @param {Element} applyButton - The apply button
 * @param {Element} statusElement - The status display element
 */
function testNextCoupon(coupons, index, couponInput, applyButton, statusElement) {
  if (index >= coupons.length) {
    // All coupons tested
    completeTestingProcess(couponInput, statusElement);
    return;
  }
  
  const code = coupons[index];
  
  // Update status
  statusElement.textContent = `Testing coupon ${index + 1}/${coupons.length}: ${code}...`;
  
  // Set the coupon code in the input
  couponInput.value = code;
  
  // Trigger input events to notify the site
  triggerInputEvents(couponInput);
  
  // Click the apply button
  simulateClick(applyButton);
  
  // Wait for page to update and check for discount
  setTimeout(() => {
    // Check if this coupon resulted in a discount
    const discount = checkForDiscount();
    
    // Update best discount if this is better
    if (discount > bestDiscount) {
      bestDiscount = discount;
      bestCode = code;
    }
    
    // Increment tested count
    dealsTested++;
    
    // Test the next coupon
    testNextCoupon(coupons, index + 1, couponInput, applyButton, statusElement);
  }, 2000); // Wait 2 seconds between tests
}

/**
 * Complete the coupon testing process
 * @param {Element} couponInput - The coupon input field
 * @param {Element} statusElement - The status display element
 */
function completeTestingProcess(couponInput, statusElement) {
  if (bestDiscount > 0) {
    // We found a working coupon
    statusElement.textContent = `Found best coupon: ${bestCode} (Saved: ${formatCurrency(bestDiscount)})`;
    statusElement.style.color = '#4CAF50';
    
    // Apply the best coupon
    couponInput.value = bestCode;
    triggerInputEvents(couponInput);
    
    // Send success message to background script
    chrome.runtime.sendMessage({
      action: 'trackCouponSuccess',
      merchantName: merchantName,
      couponCode: bestCode,
      discountAmount: bestDiscount
    });
  } else {
    // No working coupons found
    statusElement.textContent = 'No working coupons found for this store.';
    statusElement.style.color = '#F44336';
  }
}

/**
 * Check for a discount on the page
 * @returns {number} - The discount amount (0 if none found)
 */
function checkForDiscount() {
  // This is a simplified implementation
  // In a real extension, this would use various selectors and techniques
  // to identify discount amounts based on the site's structure
  
  // Look for common discount indicators
  const discountElements = document.querySelectorAll(
    '[class*="discount"], [id*="discount"], ' +
    '[class*="savings"], [id*="savings"], ' +
    '[class*="coupon"], [id*="coupon"]'
  );
  
  // Check for price changes
  for (const element of discountElements) {
    const text = element.innerText;
    
    // Look for currency indicators
    const priceMatch = text.match(/\$\s?(\d+\.?\d*)/);
    if (priceMatch && priceMatch[1]) {
      return parseFloat(priceMatch[1]);
    }
    
    // Look for percentage indicators
    const percentMatch = text.match(/(\d+\.?\d*)%/);
    if (percentMatch && percentMatch[1]) {
      // For demo purposes, we'll convert percentage to a dollar amount
      return parseFloat(percentMatch[1]) * 0.25; // Assume $0.25 per percentage point
    }
  }
  
  return 0;
}

/**
 * Trigger input events on an element to notify the site of changes
 * @param {Element} element - The input element
 */
function triggerInputEvents(element) {
  // Create and dispatch input event
  const inputEvent = new Event('input', { bubbles: true });
  element.dispatchEvent(inputEvent);
  
  // Create and dispatch change event
  const changeEvent = new Event('change', { bubbles: true });
  element.dispatchEvent(changeEvent);
  
  // Create and dispatch keyup event
  const keyupEvent = new KeyboardEvent('keyup', { bubbles: true });
  element.dispatchEvent(keyupEvent);
}

/**
 * Simulate a click on a button
 * @param {Element} button - The button element
 */
function simulateClick(button) {
  if (!button) return;
  
  // Create and dispatch click event
  const clickEvent = new MouseEvent('click', {
    view: window,
    bubbles: true,
    cancelable: true
  });
  
  button.dispatchEvent(clickEvent);
}

/**
 * Extract merchant name from URL
 * @param {string} url - The URL to extract from
 * @returns {string} - The merchant name
 */
function extractMerchantFromUrl(url) {
  try {
    const hostname = new URL(url).hostname;
    
    // Extract domain name
    const matches = hostname.match(/(?:www\.)?(.*?)(?:\.com|\.co|\.org|\.net|\.edu|\.gov|\.io)/i);
    if (matches && matches.length > 1) {
      return matches[1];
    }
    
    // Fallback: just return hostname
    return hostname;
  } catch (error) {
    console.error('Error extracting merchant name:', error);
    return 'unknown';
  }
}

/**
 * Format a currency value
 * @param {number} value - The value to format
 * @returns {string} - The formatted currency string
 */
function formatCurrency(value) {
  return '$' + value.toFixed(2);
}

/**
 * Log message to console if debug mode is enabled
 * @param  {...any} args - Arguments to log
 */
function log(...args) {
  if (DEBUG_MODE) {
    console.log('🛍️ FlashDeal:', ...args);
  }
}

// Listen for messages from the background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'processPageLinks') {
    processPageLinks();
    sendResponse({ success: true });
  }
  
  // Return true to indicate async response
  return true;
});
