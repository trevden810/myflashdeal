/**
 * FlashDeal Background Script
 * Handles background tasks including affiliate link conversion,
 * coupon retrieval, and tracking.
 */

// Configuration
const DEBUG = true;
const API_BASE_URL = 'https://api.myflashdeal.com'; // Will be replaced with actual API URL
const EXTENSION_VERSION = '1.0.0';

// Skimlinks Publisher ID
const SKIMLINKS_PUBLISHER_ID = '282846X1769229';

// eBay Partner Network credentials
const EBAY_CAMPAIGN_ID = 'tepfambiz';
const EBAY_NETWORK_ID = '9';
const EBAY_CUSTOM_ID = 'flashdeal-ext';

// Google Analytics Measurement ID
const GA_MEASUREMENT_ID = 'G-XYZ123456'; // Replace with your actual Measurement ID

// Cache for affiliate links to reduce API calls
const affiliateLinkCache = {};

// Runtime state
let isInitialized = false;
let analyticsInitialized = false;

/**
 * Initialize the background script
 */
function initialize() {
  if (isInitialized) return;
  
  log('Initializing FlashDeal background script...');
  
  // Set up listeners
  setupMessageListeners();
  setupNavigationListeners();
  
  // Initialize analytics
  initializeAnalytics();
  
  // Track extension installation
  trackEvent('extension_initialized', {
    extension_version: EXTENSION_VERSION,
    install_date: new Date().toISOString()
  });
  
  isInitialized = true;
  log('Initialization complete');
}

/**
 * Initialize Google Analytics
 */
function initializeAnalytics() {
  if (analyticsInitialized) return;
  
  // Setup GA4 in service worker context
  importScripts('https://www.googletagmanager.com/gtag/js?id=' + GA_MEASUREMENT_ID);
  
  window.dataLayer = window.dataLayer || [];
  window.gtag = function(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', GA_MEASUREMENT_ID);
  
  analyticsInitialized = true;
  log('Analytics initialized');
}

/**
 * Track an event in Google Analytics
 * @param {string} eventName - The name of the event
 * @param {Object} eventParams - The parameters for the event
 */
function trackEvent(eventName, eventParams = {}) {
  if (!analyticsInitialized) {
    initializeAnalytics();
  }
  
  if (window.gtag) {
    window.gtag('event', eventName, eventParams);
    log(`Tracked event: ${eventName}`, eventParams);
  } else {
    console.error('Failed to track event: gtag not available');
  }
}

/**
 * Set up Chrome runtime message listeners
 */
function setupMessageListeners() {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // Handle messages from content scripts
    switch (message.action) {
      case 'convertToAffiliateLink':
        handleConvertToAffiliateLink(message, sendResponse);
        break;
        
      case 'getCouponsForSite':
        handleGetCouponsForSite(message, sendResponse);
        break;
        
      case 'trackCouponSuccess':
        handleTrackCouponSuccess(message, sendResponse);
        break;
      
      case 'TRACK_EVENT':
        // Handle analytics tracking requests from content scripts
        trackEvent(message.eventName, message.eventParams);
        sendResponse({ success: true });
        break;
        
      default:
        log('Unknown message action:', message.action);
        sendResponse({ success: false, error: 'Unknown action' });
    }
    
    // Return true to indicate async response
    return true;
  });
}

/**
 * Set up navigation listeners
 */
function setupNavigationListeners() {
  // Listen for navigation completion events
  chrome.webNavigation.onCompleted.addListener((details) => {
    // Only handle main frame navigation
    if (details.frameId === 0) {
      // Tell content script to process page links
      chrome.tabs.sendMessage(details.tabId, {
        action: 'processPageLinks'
      }).catch(error => {
        // This is expected if the content script isn't loaded yet
        if (!error.toString().includes('Could not establish connection')) {
          console.error('Navigation listener error:', error);
        }
      });
    }
  });
}

/**
 * Handle request to convert a link to an affiliate link
 * @param {Object} message - The message object
 * @param {Function} sendResponse - Function to send response
 */
async function handleConvertToAffiliateLink(message, sendResponse) {
  const { originalUrl, merchantName } = message;
  
  // Validate URL
  if (!originalUrl || !originalUrl.startsWith('http')) {
    sendResponse({ success: false, error: 'Invalid URL' });
    return;
  }
  
  // Check cache first
  if (affiliateLinkCache[originalUrl]) {
    sendResponse({
      success: true,
      originalUrl,
      affiliateUrl: affiliateLinkCache[originalUrl],
      merchantName: merchantName || extractMerchantFromUrl(originalUrl),
      fromCache: true
    });
    return;
  }
  
  try {
    // Process based on merchant
    let affiliateUrl = originalUrl;
    let affiliateNetwork = 'none';
    
    // Apply merchant-specific logic
    if (originalUrl.includes('ebay.com')) {
      affiliateUrl = generateEbayAffiliateLink(originalUrl);
      affiliateNetwork = 'ebay';
    }
    else if (originalUrl.includes('walmart.com')) {
      // Placeholder for Walmart - will be implemented after approval
      affiliateUrl = originalUrl;
      affiliateNetwork = 'walmart';
    }
    else if (originalUrl.includes('target.com')) {
      // Placeholder for Target - will be implemented after approval
      affiliateUrl = originalUrl;
      affiliateNetwork = 'target';
    }
    else {
      // Use Skimlinks for all other merchants
      affiliateUrl = generateSkimlinksAffiliateLink(originalUrl);
      affiliateNetwork = 'skimlinks';
    }
    
    // Cache the result
    affiliateLinkCache[originalUrl] = affiliateUrl;
    
    // Track affiliate link generation
    trackEvent('affiliate_link_generated', {
      merchant_name: merchantName || extractMerchantFromUrl(originalUrl),
      affiliate_network: affiliateNetwork,
      original_url: originalUrl
    });
    
    // Send response
    sendResponse({
      success: true,
      originalUrl,
      affiliateUrl,
      merchantName: merchantName || extractMerchantFromUrl(originalUrl),
      affiliateNetwork
    });
    
    // Log the conversion
    log(`Converted link: ${originalUrl} → ${affiliateUrl} (${affiliateNetwork})`);
  } catch (error) {
    console.error('Error converting affiliate link:', error);
    sendResponse({ success: false, error: error.message });
  }
}

/**
 * Generate an eBay Partner Network affiliate link
 * @param {string} originalUrl - The original eBay product URL
 * @returns {string} - The affiliate link
 */
function generateEbayAffiliateLink(originalUrl) {
  const separator = originalUrl.includes('?') ? '&' : '?';
  
  // Generate a unique click ID for better tracking
  const clickId = generateClickId();
  
  // Track the eBay link generation event
  trackEvent('ebay_link_generated', {
    original_url: originalUrl,
    click_id: clickId
  });
  
  return `${originalUrl}${separator}mkevt=1&mkcid=${EBAY_CAMPAIGN_ID}&mkrid=${clickId}&campid=${EBAY_CAMPAIGN_ID}&toolid=10001&customid=${EBAY_CUSTOM_ID}`;
}

/**
 * Generate a unique click ID for eBay Partner Network tracking
 * @returns {string} - A unique click ID
 */
function generateClickId() {
  return 'fd-' + Math.random().toString(36).substring(2, 10) + '-' + Date.now().toString(36);
}

/**
 * Generate a Skimlinks affiliate link
 * @param {string} originalUrl - The original URL
 * @returns {string} - The Skimlinks affiliate link
 */
function generateSkimlinksAffiliateLink(originalUrl) {
  return `https://go.skimresources.com?id=${SKIMLINKS_PUBLISHER_ID}&url=${encodeURIComponent(originalUrl)}`;
}

/**
 * Handle request to get coupons for a website
 * @param {Object} message - The message object
 * @param {Function} sendResponse - Function to send response
 */
async function handleGetCouponsForSite(message, sendResponse) {
  const { merchantName, url } = message;
  
  // Track coupon request
  trackEvent('coupon_request', {
    merchant_name: merchantName,
    url: url
  });
  
  // In a real implementation, this would call a backend API
  // For now, return sample coupon codes based on merchant
  let coupons = [];
  
  switch (merchantName.toLowerCase()) {
    case 'amazon':
      coupons = ['WELCOME10', 'PRIME20', 'SAVE15NOW'];
      break;
    case 'walmart':
      coupons = ['SAVE20', 'FREESHIP', 'NEWCUST15'];
      break;
    case 'ebay':
      coupons = ['FLASH25', 'EBAY10', 'WELCOME15'];
      break;
    case 'target':
      coupons = ['TARGET20', 'REDCARD5', 'NEWAPP10'];
      break;
    default:
      // Generic coupons
      coupons = ['WELCOME10', 'SAVE15', 'FREESHIP', 'NEWCUST', 'FLASH20'];
  }
  
  // Send the coupons
  sendResponse({
    success: true,
    merchantName,
    url,
    coupons
  });
  
  log(`Returned ${coupons.length} coupons for ${merchantName}`);
}

/**
 * Handle tracking of successful coupon applications
 * @param {Object} message - The message object
 * @param {Function} sendResponse - Function to send response
 */
async function handleTrackCouponSuccess(message, sendResponse) {
  const { merchantName, couponCode, discountAmount, discountType } = message;
  
  // Track successful coupon application
  trackEvent('coupon_applied', {
    merchant_name: merchantName,
    coupon_code: couponCode,
    discount_amount: discountAmount,
    discount_type: discountType || 'unknown'
  });
  
  // In a real implementation, this would send data to a backend API
  log(`Tracking coupon success: ${couponCode} at ${merchantName}, saved ${discountAmount}`);
  
  // Send success response
  sendResponse({
    success: true,
    tracked: true
  });
}

/**
 * Extract merchant name from URL
 * @param {string} url - The URL to extract from
 * @returns {string} - The merchant name
 */
function extractMerchantFromUrl(url) {
  try {
    const hostname = new URL(url).hostname;
    
    // Extract domain name
    const matches = hostname.match(/(?:www\.)?(.*?)(?:\.com|\.co|\.org|\.net|\.edu|\.gov|\.io)/i);
    if (matches && matches.length > 1) {
      return matches[1];
    }
    
    // Fallback: just return hostname
    return hostname;
  } catch (error) {
    console.error('Error extracting merchant name:', error);
    return 'unknown';
  }
}

/**
 * Log message to console if debug mode is enabled
 * @param  {...any} args - Arguments to log
 */
function log(...args) {
  if (DEBUG) {
    console.log('🛍️ FlashDeal (BG):', ...args);
  }
}

// Initialize the background script
initialize();