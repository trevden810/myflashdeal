/**
 * AnalyticsService.js - Service for tracking extension usage and affiliate link clicks
 */

class AnalyticsService {
  constructor() {
    this.initialized = false;
    this.measurementId = 'G-XYZ123456'; // Replace with your actual Measurement ID
  }

  /**
   * Initialize Google Analytics
   */
  initialize() {
    if (this.initialized) return;
    
    // Use chrome.runtime to inject analytics script
    chrome.runtime.sendMessage({
      type: 'INJECT_ANALYTICS',
      measurementId: this.measurementId
    });
    
    this.initialized = true;
    console.log('Analytics service initialized');
  }

  /**
   * Track an event
   * @param {string} eventName - Name of the event
   * @param {Object} eventParams - Event parameters
   */
  trackEvent(eventName, eventParams = {}) {
    // Send event tracking message to background script
    chrome.runtime.sendMessage({
      type: 'TRACK_EVENT',
      eventName: eventName,
      eventParams: eventParams
    });
    
    console.log(`Tracked event: ${eventName}`, eventParams);
  }

  /**
   * Track affiliate link click
   * @param {string} merchantName - The merchant name
   * @param {string} affiliateNetwork - The affiliate network
   * @param {string} url - The affiliate URL
   */
  trackAffiliateClick(merchantName, affiliateNetwork, url) {
    this.trackEvent('affiliate_link_click', {
      merchant_name: merchantName,
      affiliate_network: affiliateNetwork,
      url: url,
      timestamp: new Date().toISOString()
    });
  }

  /**
   * Track extension usage data
   * @param {string} action - The action performed
   * @param {Object} data - Additional data about the action
   */
  trackUsage(action, data = {}) {
    this.trackEvent('extension_usage', {
      action: action,
      ...data,
      timestamp: new Date().toISOString()
    });
  }
}

// Create singleton instance
const analyticsService = new AnalyticsService();

// Export the service
export default analyticsService;