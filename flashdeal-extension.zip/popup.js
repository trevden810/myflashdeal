// FlashDeal popup.js - Handles popup UI interactions

document.addEventListener('DOMContentLoaded', function() {
  // Initialize popup with latest data
  initializePopup();
  
  // Set up event listeners
  document.querySelector('.auto-apply input').addEventListener('change', toggleAutoApply);
});

// Initialize popup with latest data from storage
function initializePopup() {
  chrome.storage.local.get(['stats', 'currentDeals', 'settings'], function(result) {
    // If we have stats stored, update the UI
    if (result.stats) {
      updateStats(result.stats);
    }
    
    // If we have current deals, update the deals list
    if (result.currentDeals) {
      updateDeals(result.currentDeals);
    } else {
      // If no deals available, show a message
      document.getElementById('deals-container').innerHTML = 
        '<div class="no-deals">No deals available for the current site</div>';
    }
    
    // Set the auto-apply toggle based on settings
    if (result.settings) {
      document.querySelector('.auto-apply input').checked = result.settings.autoApply;
    }
  });
  
  // Get the current active tab to check for available coupons
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    if (tabs[0]) {
      const currentUrl = new URL(tabs[0].url);
      const domain = currentUrl.hostname;
      
      // Update header to show current site
      updateHeaderForSite(domain);
      
      // Send message to background script to check for deals on this domain
      chrome.runtime.sendMessage({
        action: 'checkDeals',
        domain: domain
      });
    }
  });
}

// Update the stats section with the provided data
function updateStats(stats) {
  const statElements = document.querySelectorAll('.stat-value');
  
  // Total savings
  statElements[0].textContent = '$' + stats.totalSavings.toFixed(2);
  
  // Coupons applied
  statElements[1].textContent = stats.couponsApplied;
  
  // Success rate
  statElements[2].textContent = stats.successRate + '%';
}

// Update the deals list with the provided deals
function updateDeals(deals) {
  const dealsContainer = document.getElementById('deals-container');
  
  // Clear existing deals
  dealsContainer.innerHTML = '';
  
  if (deals.length === 0) {
    dealsContainer.innerHTML = '<div class="no-deals">No deals available for the current site</div>';
    return;
  }
  
  // Add each deal to the container
  deals.forEach(function(deal) {
    const dealElement = document.createElement('div');
    dealElement.className = 'deal-item';
    
    const storeElement = document.createElement('div');
    storeElement.className = 'deal-store';
    storeElement.textContent = deal.store;
    
    const codeElement = document.createElement('span');
    codeElement.className = 'deal-code';
    codeElement.textContent = deal.code;
    
    const discountElement = document.createElement('span');
    discountElement.className = 'deal-discount';
    discountElement.textContent = deal.discount;
    
    dealElement.appendChild(storeElement);
    dealElement.appendChild(codeElement);
    dealElement.appendChild(discountElement);
    
    // Add click event to apply this specific coupon
    dealElement.addEventListener('click', function() {
      applyCoupon(deal);
    });
    
    dealsContainer.appendChild(dealElement);
  });
}

// Update the header to show the current site
function updateHeaderForSite(domain) {
  // Clean up the domain for display (remove www., etc.)
  const displayDomain = domain.replace(/^www\./, '');
  
  // Update the header with the current site info if needed
  // This could show something like "Deals for Amazon.com"
}

// Toggle auto-apply setting
function toggleAutoApply(event) {
  const autoApply = event.target.checked;
  
  // Save setting to storage
  chrome.storage.local.set({
    settings: { autoApply: autoApply }
  });
  
  // Notify background script of the change
  chrome.runtime.sendMessage({
    action: 'updateSettings',
    settings: { autoApply: autoApply }
  });
}

// Apply a specific coupon
function applyCoupon(deal) {
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    if (tabs[0]) {
      // Send message to content script to apply this coupon
      chrome.tabs.sendMessage(tabs[0].id, {
        action: 'applyCoupon',
        coupon: deal
      });
    }
  });
}